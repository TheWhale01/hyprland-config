# Changelog

## 1.0 - 2022-06-17

- It Lives!
- Forked from sddm-sugar-candy 1.6(?)
- Removed text from username field (sddm-sugar-candy#1)
- Fixed username and password font size (sddm-sugar-candy!17)
- Set default password character visibility to a saner value to prevent shouldersurfing
- Fixed portrait orientation layout
  - coincidentally fixed gaussian blur on Wayland, no idea what the resolution was, suspect import of QtQuick.Window.
